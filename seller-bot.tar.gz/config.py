# config.py
import os
from dotenv import load_dotenv

load_dotenv()

CLAUDE_API_KEY = os.getenv("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")